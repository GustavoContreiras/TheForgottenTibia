Gesior2012
==========

Gesior 2012 - Account Maker [website] for OTSes
Select 'branch' for your OTS (TFS) version.

## TODO list

* Improve the design and functionality of shop system;
* Add social box on right sidebar of TIBIACOM layout.
* Update the experience table with new levels.
