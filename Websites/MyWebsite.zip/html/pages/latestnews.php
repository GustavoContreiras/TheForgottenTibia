<?php
if(!defined('INITIALIZED'))
    exit;
/*
// top kills - guilds
$main_content .= '<table border="0" width="100%">
    <tr>
        <td style="text-align: center; font-weight: bold;">
            <center><font color="red">Most powerfull guilds</font></center>
        </td>
    </tr>
</table>';

$main_content .= '<table border="0" cellspacing="3" cellpadding="4" width="100%"><tr>';

foreach($SQL->query('SELECT ' . $SQL->tableName('g') . '.' . $SQL->fieldName('id') . ' AS ' . $SQL->fieldName('id') . ', ' . $SQL->tableName('g') . '.' . $SQL->fieldName('name') . ' AS ' . $SQL->fieldName('name') . ', COUNT(' . $SQL->tableName('g') . '.' . $SQL->fieldName('name') . ') AS ' . $SQL->fieldName('frags') . ' FROM ' . $SQL->tableName('killers') . ' k LEFT JOIN ' . $SQL->tableName('player_killers') . ' pk ON ' . $SQL->tableName('k') . '.' . $SQL->fieldName('id') . ' = ' . $SQL->tableName('pk') . '.' . $SQL->fieldName('kill_id') . ' LEFT JOIN ' . $SQL->tableName('players') . ' p ON ' . $SQL->tableName('pk') . '.' . $SQL->fieldName('player_id') . ' = ' . $SQL->tableName('p') . '.' . $SQL->fieldName('id') . ' LEFT JOIN ' . $SQL->tableName('guild_ranks') . ' gr ON ' . $SQL->tableName('p') . '.' . $SQL->fieldName('rank_id') . ' = ' . $SQL->tableName('gr') . '.' . $SQL->fieldName('id') . ' LEFT JOIN ' . $SQL->tableName('guilds') . ' g ON ' . $SQL->tableName('gr') . '.' . $SQL->fieldName('guild_id') . ' = ' . $SQL->tableName('g') . '.' . $SQL->fieldName('id') . ' WHERE ' . $SQL->tableName('g') . '.' . $SQL->fieldName('id') . ' > 0 AND ' . $SQL->tableName('k') . '.' . $SQL->fieldName('unjustified') . ' = 1 AND ' . $SQL->tableName('k') . '.' . $SQL->fieldName('final_hit') . ' = 1 GROUP BY ' . $SQL->fieldName('name') . ' ORDER BY ' . $SQL->fieldName('frags') . ' DESC, ' . $SQL->fieldName('name') . ' ASC LIMIT 4;') as $guild)
$main_content .= '<td style="width: 25%; text-align: center;"><a href="?subtopic=guilds&action=show&guild=' . $guild['id'] . '"><img src="guild_image.php?id=' . $guild['id'] . '" width="64" height="64" border="0"/><br />' . htmlspecialchars($guild['name']) . '</a><br />' . $guild['frags'] . ' kills
</td>';
$main_content .= '</tr></table>';
*/

function replaceSmile($text, $smile)
{
    $smileys = array(';D' => 1, ':D' => 1, ':cool:' => 2, ';cool;' => 2, ':ekk:' => 3, ';ekk;' => 3, ';o' => 4, ';O' => 4, ':o' => 4, ':O' => 4, ':(' => 5, ';(' => 5, ':mad:' => 6, ';mad;' => 6, ';rolleyes;' => 7, ':rolleyes:' => 7, ':)' => 8, ';d' => 9, ':d' => 9, ';)' => 10);
    if($smile == 1)
        return $text;
    else
    {
        foreach($smileys as $search => $replace)
            $text = str_replace($search, '<img src="images/forum/smile/'.$replace.'.gif" />', $text);
        return $text;
    }
}

function replaceAll($text, $smile)
{
    $rows = 0;
    while(stripos($text, '[code]') !== false && stripos($text, '[/code]') !== false )
    {
        $code = substr($text, stripos($text, '[code]')+6, stripos($text, '[/code]') - stripos($text, '[code]') - 6);
        if(!is_int($rows / 2)) { $bgcolor = 'ABED25'; } else { $bgcolor = '23ED25'; } $rows++;
        $text = str_ireplace('[code]'.$code.'[/code]', '<i>Code:</i><br /><table cellpadding="0" style="background-color: #'.$bgcolor.'; width: 480px; border-style: dotted; border-color: #CCCCCC; border-width: 2px"><tr><td>'.$code.'</td></tr></table>', $text);
    }
    $rows = 0;
    while(stripos($text, '[quote]') !== false && stripos($text, '[/quote]') !== false )
    {
        $quote = substr($text, stripos($text, '[quote]')+7, stripos($text, '[/quote]') - stripos($text, '[quote]') - 7);
        if(!is_int($rows / 2)) { $bgcolor = 'AAAAAA'; } else { $bgcolor = 'CCCCCC'; } $rows++;
        $text = str_ireplace('[quote]'.$quote.'[/quote]', '<table cellpadding="0" style="background-color: #'.$bgcolor.'; width: 480px; border-style: dotted; border-color: #007900; border-width: 2px"><tr><td>'.$quote.'</td></tr></table>', $text);
    }
    $rows = 0;
    while(stripos($text, '[url]') !== false && stripos($text, '[/url]') !== false )
    {
        $url = substr($text, stripos($text, '[url]')+5, stripos($text, '[/url]') - stripos($text, '[url]') - 5);
        $text = str_ireplace('[url]'.$url.'[/url]', '<a href="'.$url.'" target="_blank">'.$url.'</a>', $text);
    }
    while(stripos($text, '[player]') !== false && stripos($text, '[/player]') !== false )
    {
        $player = substr($text, stripos($text, '[player]')+8, stripos($text, '[/player]') - stripos($text, '[player]') - 8);
        $text = str_ireplace('[player]'.$player.'[/player]', '<a href="?subtopic=characters&name='.urlencode($player).'">'.$player.'</a>', $text);
    }
    while(stripos($text, '[img]') !== false && stripos($text, '[/img]') !== false )
    {
        $img = substr($text, stripos($text, '[img]')+5, stripos($text, '[/img]') - stripos($text, '[img]') - 5);
        $text = str_ireplace('[img]'.$img.'[/img]', '<img src="'.$img.'">', $text);
    }
    while(stripos($text, '[b]') !== false && stripos($text, '[/b]') !== false )
    {
        $b = substr($text, stripos($text, '[b]')+3, stripos($text, '[/b]') - stripos($text, '[b]') - 3);
        $text = str_ireplace('[b]'.$b.'[/b]', '<b>'.$b.'</b>', $text);
    }
    while(stripos($text, '[i]') !== false && stripos($text, '[/i]') !== false )
    {
        $i = substr($text, stripos($text, '[i]')+3, stripos($text, '[/i]') - stripos($text, '[i]') - 3);
        $text = str_ireplace('[i]'.$i.'[/i]', '<i>'.$i.'</i>', $text);
    }
    while(stripos($text, '[u]') !== false && stripos($text, '[/u]') !== false )
    {
        $u = substr($text, stripos($text, '[u]')+3, stripos($text, '[/u]') - stripos($text, '[u]') - 3);
        $text = str_ireplace('[u]'.$u.'[/u]', '<u>'.$u.'</u>', $text);
    }
    return replaceSmile($text, $smile);
}

function showPost($topic, $text, $smile)
{
    $text = nl2br($text);
    $post = '';
    if(!empty($topic))
        $post .= '<b>'.replaceSmile($topic, $smile).'</b>';
    $post .= replaceAll($text, $smile);
    return $post;
}
    $last_featuredArticle = $SQL->query('SELECT ' . $SQL->tableName('players') . '.' . $SQL->fieldName('name') . ', ' . $SQL->tableName('z_forum') . '.' . $SQL->fieldName('post_text') . ', ' . $SQL->tableName('z_forum') . '.' . $SQL->fieldName('post_topic') . ', ' . $SQL->tableName('z_forum') . '.' . $SQL->fieldName('post_smile') . ', ' . $SQL->tableName('z_forum') . '.' . $SQL->fieldName('id') . ', ' . $SQL->tableName('z_forum') . '.' . $SQL->fieldName('replies') . ', ' . $SQL->tableName('z_forum') . '.' . $SQL->fieldName('post_date') . ' FROM ' . $SQL->tableName('players') . ', ' . $SQL->tableName('z_forum') . ' WHERE ' . $SQL->tableName('players') . '.' . $SQL->fieldName('id') . ' = ' . $SQL->tableName('z_forum') . '.' . $SQL->fieldName('author_guid') . ' AND ' . $SQL->tableName('z_forum') . '.' . $SQL->fieldName('section') . ' = 1 AND ' . $SQL->tableName('z_forum') . '.' . $SQL->fieldName('first_post') . ' = ' . $SQL->tableName('z_forum') . '.' . $SQL->fieldName('id') . ' AND ' . $SQL->tableName('z_forum') . '.' . $SQL->fieldName('post_topic') . '=\'Featured Article\'' . ' ORDER BY ' . $SQL->tableName('z_forum') . '.' . $SQL->fieldName('last_post') . ' DESC LIMIT 1')->fetchAll();
    if(isset($last_featuredArticle[0]))
    {

  $featuredArticle = '<div id="featuredarticle" class="Box">
    <div class="Corner-tl" style="background-image:url('.$layout_name.'/images/general/corner-tl.gif);"></div>
    <div class="Corner-tr" style="background-image:url('.$layout_name.'/images/general/corner-tr.gif);"></div>
    <div class="Border_1" style="background-image:url('.$layout_name.'/images/general/border-1.gif);"></div>
    <div class="BorderTitleText" style="background-image:url('.$layout_name.'/images/general/title-background-green.gif);"></div><img id="ContentBoxHeadline" class="Title" src="'.$layout_name.'/images/general/headline-featuredarticle.gif" alt="Contentbox headline">    
    <div class="Border_2">
      <div class="Border_3">
        <div class="BoxContent" style="background-image:url('.$layout_name.'/images/general/scroll.gif);">';

    foreach($last_featuredArticle as $fArticle)
    {
        $featuredArticle .= '<a id="Link" style="position: absolute; margin-bottom: 10px; top: 2px;" href="?subtopic=forum&action=show_thread&id=' . $fArticle['id'] . '">» read more</a><div id="TeaserText">'.substr(showPost('', $fArticle['post_text'], $fArticle['post_smile']), 0, 400).'</div>';
    }

    $featuredArticle .= '</div>
      </div>
    </div>
    <div class="Border_1" style="background-image:url('.$layout_name.'/images/general/border-1.gif);"></div>
    <div class="CornerWrapper-b"><div class="Corner-bl" style="background-image:url('.$layout_name.'/images/general/corner-bl.gif);"></div></div>
    <div class="CornerWrapper-b"><div class="Corner-br" style="background-image:url('.$layout_name.'/images/general/corner-br.gif);"></div></div>
  </div>';
}

$popUp = '
<div id="LayerPop" style="display:block; position:absolute; left:0px; top:0px; background-color:#1e1e22; width:100%; height:100%; z-index:100;margin:0px;opacity:0.75;"></div>
<div id="LayerPop2" style="position: absolute; top: 10%; margin:auto; padding:auto; width: 100%; z-index: 5000;" align="center">
	<a href="javascript:void();" onclick="document.getElementById(\'LayerPop\').style.display = \'none\';document.getElementById(\'LayerPop2\').style.display = \'none\'">
		<img src="'.$layout_name.'/images/popup.png">
		<div id="LayerPop3" style="text-decoration:none; position: absolute; top: 84%; margin:auto; padding:auto; width: 100%; z-index: 5001;" align="center">
			<font color="#e9b857" size="5"><b>Click to play!</b></font>
		</div>
	</a>
</div>';

$main_content = '
<img id="ServerInformations" style="position: absolute;margin-left:0%;margin-top:-5%; z-index: 5;" src="layouts/tibiacom/images/server_informations.png" alt="Server Information">
<table align="center" width="95%">
    <tr>
        <td style="width:50%;"><br><center>
            No more training to advance skills!<br>
            No more skill loss on deaths!<br>
            No more vocations! Create your own build!<br><br></center>
        </td>
            <td style="width:50%;">
            <center>

            <style>
            .zoomButtonDownload {
                padding: 3px;
                border: 2px solid #555555;
                border-radius:15px;
                padding: 10px;
                background-color: #19381e;
                transition: transform .1s;
                width: 200px;
            }

            .zoomButtonDownload:hover {
                transform: scale(1.025);
            }
            </style>
            <div class="zoomButtonDownload">
            <font size="4">
            <a style="text-decoration:none; color:#e5e5e5;" href="http://www.mediafire.com/file/vqxbr4ngyc8i62i/TheForgottenTibia_17-10-19.zip/file" target="_blank">Download Client</font><br><font size="1">with full minimap</a>
            
            </font>
            </center>
            <center>
            <font size="1">
            (
            <a style="color: #19381e;" href="https://download.microsoft.com/download/0/6/4/064F84EA-D1DB-4EAA-9A5C-CC2F0FF6A638/vc_redist.x86.exe">vc_redist.x86.exe</a> required to play
            )
            </font>
            </center>
            </div>
		
        </td>
    </tr>
</table>

<table align="center" style="width:95%;">
    <tr>
        <td style="width:50%;text-align:center;">
	    Increase your power by adding skill points to:<br><br>
            <img style="width:50%;" id="Skills" style="width:95%;"src="/layouts/tibiacom/images/skills.gif" alt="Skills">
        </td>
        <td style="width:50%;text-align:center;">
	    Each level you advance you will receive:<br><br>
            <b>+5 Health</b><br>
            <b>+5 Mana</b><br>
            <b>+10 Capacity</b><br>
            <b>+1 Speed</b><br>
            <br>
            <b>+2 Skill Points</b> - level 1 to 8<br>
            <b>+4 Skill Points</b> - level 9 to 40<br>
            <b>+3 Skill Points</b> - level 41 to 60<br>
            <b>+2 Skill Points</b> - level 61 to 80<br>
            <b>+1 Skill Point</b> - level 81+<br><br><br>
		<center><a style="color: #19381e;" href="https://chat.whatsapp.com/GuJRIkxd2l78y6hfIlsYtn">WhatsApp Group (BR)</a></center>
		<br>
		<center><a style="color: #19381e;" href="https://discordapp.com/channels/634449030591807518/634449031363428353">Discord</a></center>
        </td>
    </tr>
</table>';

$main_content .= '
<div id="newsticker" class="Box">   
    <div class="BoxContent" style="background-image:url('.$layout_name.'/images/general/scroll.gif);">';

        // KNIGHT
        $main_content .= '
        <div id="TickerEntry-1" class="Row" onclick="TickerAction(&quot;TickerEntry-1&quot;)">
            <div class="NewsTickerIcon"></div>
            <div id="TickerEntry-1-Button" class="NewsTickerExtend" style="background-image: url('.$layout_name.'/images/general/plus.gif);"></div>
            <div class="NewsTickerText">
                <div id="TickerEntry-1-ShortText" class="NewsTickerShortText" style="display: block;"><b>Knight Gameplay</b> ...</div>
                <div id="TickerEntry-1-FullText" class="NewsTickerFullText" style="display: none;">
                    <center><b>Knight Gameplay</b></center><br>
                    You should increase your <b>vitality</b>, <b>strenght</b>, <b>defence</b> and <b>endurance</b>, but if you will be a full damage warrior using a two-handed weapon, probably you won\'t need the <b>defence</b> skill.<br>
                    <br>
                    - <b>Clubs</b>, <b>swords</b> and <b>axes</b> have their damage based on <b>strenght</b>.<br>
                    - <b>Dual-handed melee weapons</b> gives +25% <b>critical hit chance</b>, +100% <b>critical hit damage</b> and it has a chance of giving <b>bleeding condition</b> to target.<br>
                    - <b>One-handed melee weapons</b> can be <b>dual-wielded</b>:<br>
                      <font size="1">* It fixes your attack speed in 200% but decreases your weapon attack to 75%.</font><br>
                    <br>
                    <table><tr><td><img id="Quiver" style="width:100%;border:3px solid #021a40;"src="'.$layout_name.'/images/dual-wield.gif" alt="Dual-Wield"></td></tr></table><br>
                    Check out our <a href="?subtopic=classicknight">build tutorial for knights!</a>
                </div>
            </div>
        </div>';

        // RANGER
        $main_content .= '
        <div id="TickerEntry-2" class="Row" onclick="TickerAction(&quot;TickerEntry-2&quot;)">
            <div class="NewsTickerIcon"></div>
            <div id="TickerEntry-2-Button" class="NewsTickerExtend" style="background-image: url('.$layout_name.'/images/general/plus.gif);"></div>
            <div class="NewsTickerText">
                <div id="TickerEntry-2-ShortText" class="NewsTickerShortText" style="display: block;"><b>Ranger Gameplay</b> ...</div>
                <div id="TickerEntry-2-FullText" class="NewsTickerFullText" style="display: none;">
                    <center><b>Ranger Gameplay</b></center><br>
                    You can have an one-handed distance build increasing <b>dexterity</b> and <b>resistance</b> as main skills or you can have a two-handed distance build increasing <b>dexterity</b> and <b>strenght</b>.<br>
                    <br>
                    - <b>Dual-handed distance weapons</b> are based 75% on <b>dexterity</b> and 50% on <b>strenght</b>.<br>
                    - <b>One-handed distance weapons</b> are based 100% on <b>dexterity</b>.<br>
                    - Each <b>dexterity</b> skill advanced will give you +0.25% walk speed and 0.25% attack speed.<br>
                    - <b>Ammunitions</b> can be placed in a <b>quiver</b> in the <b>ammo slot</b>. This way you don\'t need to refill every time.<br>
                    <br>
                    <table><tr><td><img id="Quiver" style="width:100%;border:3px solid #021a40;"src="'.$layout_name.'/images/ezgif.com-crop.gif" alt="Quiver"></td></tr></table><br>
                    Check out our <a href="?subtopic=classicranger">build tutorial for rangers!</a>
                </div>
            </div>
        </div>';

        // MAGE
        $main_content .= '
        <div id="TickerEntry-3" class="Row" onclick="TickerAction(&quot;TickerEntry-3&quot;)">
            <div class="NewsTickerIcon"></div>
            <div id="TickerEntry-3-Button" class="NewsTickerExtend" style="background-image: url('.$layout_name.'/images/general/plus.gif);"></div>
            <div class="NewsTickerText">
                <div id="TickerEntry-3-ShortText" class="NewsTickerShortText" style="display: block;"><b>Mage Gameplay</b> ...</div>
                <div id="TickerEntry-3-FullText" class="NewsTickerFullText" style="display: none;">
                    <center><b>Mage Gameplay</b></center><br>
                    Basically you will increase your <b>magic</b>.<br>
                    Then you should take a look in our <a href="?subtopic=spells"> spell list</a> to know if you prefer to increase <b>faith</b> and/or <b>intelligence</b>.<br>
                    You can use the spellbook button in top right of the client to see available spells for you.<br>
                    <font size="1">* If the client is outdated some values can be wrong. Access the spell list on website if you think something is incorrect.</font><br>
                    <br>
                    - <b>Spells</b> and <b>runes</b> have their power based on <b>magic</b>.<br>
                    - <b>Rod\'s maximum damage</b> is increased by 2% each <b>faith</b> skill you add.<br>
                    - <b>Wands\'s maximum damage</b> is increased by 1% each <b>intelligence</b> skill you add.<br>
                    <br>
                    <center>
                    <table>
					<tr>
						<td>
						<img id="Wand" style="width:100%;border:3px solid #021a40;"src="'.$layout_name.'/images/wand-intelligence.gif" alt="Wand-Intelligence">
						</td>
					</tr>
					</table>
                    </center><br>
                    Check out our <a href="?subtopic=classicmage">build tutorial for mages!</a>
                </div>
            </div>
        </div>';

        // AUTO LOOT
        $main_content .= '
        <div id="TickerEntry-9" class="Row" onclick="TickerAction(&quot;TickerEntry-9&quot;)">
            <div class="NewsTickerIcon"></div>
            <div id="TickerEntry-9-Button" class="NewsTickerExtend" style="background-image: url('.$layout_name.'/images/general/plus.gif);"></div>
            <div class="NewsTickerText">
                <div id="TickerEntry-9-ShortText" class="NewsTickerShortText" style="display: block;"><b>Auto-Loot</b> ...</div>
                <div id="TickerEntry-9-FullText" class="NewsTickerFullText" style="display: none;">
                    <center><b>Auto-Loot</b></center><br>
                    <center>
                    <table>
                    <tr>
                        <td style="vertical-align:top;">
                            You can choose if you want to loot automatically gold coins and/or addon items.<br><br>
                            You just have to ctrl + click on your character and choose the option you desire.
                        </td>
                        <td>
                            <img id="Auto-Loot" style="width:100%;border:3px solid #021a40;"src="'.$layout_name.'/images/auto-loot.gif" alt="Auto-Loot">
                        </td>
                    </tr>
                    </table>
                    </center><br>
                </div>
            </div>
        </div>';

        // TITLE
        $main_content .= '
        <div id="TickerEntry-10" class="Row" onclick="TickerAction(&quot;TickerEntry-10&quot;)">
            <div class="NewsTickerIcon"></div>
            <div id="TickerEntry-10-Button" class="NewsTickerExtend" style="background-image: url('.$layout_name.'/images/general/plus.gif);"></div>
            <div class="NewsTickerText">
                <div id="TickerEntry-10-ShortText" class="NewsTickerShortText" style="display: block;"><b>Title System</b> ...</div>
                <div id="TickerEntry-10-FullText" class="NewsTickerFullText" style="display: none;">
                	<center><b>Title System</b></center><br>
                    <center>
                    <table>
                    	<tr>
                    	<td>
	                    	<table border="0" style="width:95%;text-align:center;">
	                    		<tr><td>After you reach a certain skill you can get a title to your character.</td></tr>
	                    	</table>
	                	</td>
	                	<td>
	                    <table style="width:98%; border:1px solid black;text-align:center" cellspacing="1" cellpadding="4" align="center">
	                    	<TR style="text-align:center;" BGCOLOR='.$config['site']['vdarkborder'].'>
		                    	<TD style="border:1px solid black;" CLASS=white>
		                    	<B><font CLASS=white>Title</B>
		                    	</TD>
		                    	<TD style="border:1px solid black;" width="120" CLASS=white>
		                    	<B><font CLASS=white>Minimum Skill</B>
		                    	</TD>
		                    </TR>
		                    <tr><td style="border:1px solid black;">Mage</td><td style="border:1px solid black;">Intelligence 60</td></tr>
		                    <tr><td style="border:1px solid black;">Ranger</td><td style="border:1px solid black;">Dexterity 90</td></tr>
		                    <tr><td style="border:1px solid black;">Knight</td><td style="border:1px solid black;">Strenght 90</td></tr>
		                    <tr><td style="border:1px solid black;">Supporter</td><td style="border:1px solid black;">Faith 40<br><font size=1>or</font><br>Defence 90</td></tr>
	                    </table>
	                    </td>
	                    </tr>
	                </table>
                    </center>
                </div>
            </div>
        </div>';

        // QUESTS
        $main_content .= '
        <div id="TickerEntry-4" class="Row" onclick="TickerAction(&quot;TickerEntry-4&quot;)">
            <div class="NewsTickerIcon"></div>
            <div id="TickerEntry-4-Button" class="NewsTickerExtend" style="background-image: url('.$layout_name.'/images/general/plus.gif);"></div>
            <div class="NewsTickerText">
                <div id="TickerEntry-4-ShortText" class="NewsTickerShortText" style="display: block;"><b>Quests</b> ...</div>
                <div id="TickerEntry-4-FullText" class="NewsTickerFullText" style="display: none;">
                    <center><table border="0" style="width:100%;text-align:center;">
                    <tr><td width="30%"><b>Quest</b></td><td><b>Level</b></td><td><b>Reward</b></td><td width="18%"><b>Location</b></td></tr>
                    <tr><td>The Plate Armor</td><td>8</td><td style="font-size:10px;">Plate Armor</td><td>Graveyard</td></tr>
                    <tr><td>The Plate Legs</td><td>8</td><td style="font-size:10px;">Plate Legs</td><td>Cyclopolis</td></tr>
                    <tr><td>The Parchment Room</td><td>8</td><td style="font-size:10px;">Stealth Ring, 2 Talons, Bone, Skull, Parchment and a Golden Key</td><td>Graveyard</td></tr>
                    <tr><td>The Stealth Ring</td><td>8</td><td style="font-size:10px;">Stealth Ring</td><td>Minotaurs Tower</td></tr>
                    <tr><td>Double Hero</td><td>8</td><td style="font-size:10px;">Red Gem and Strenght Ring</td><td>Graveyard</td></tr>
                    <tr><td>Greenhorn Arena</td><td>20</td><td style="font-size:10px;">Bronze Goblet and Orcish Maul or Headchopper or Blacksteel Sword</td><td>Svargrond</td></tr>
                    <tr><td>Crown Helmet & Noble Armor</td><td>30</td><td style="font-size:10px;">Crown Helmet and Noble Armor</td><td>Graveyard</td></tr>
                    <tr><td>Crusader Helmet</td><td>35</td><td style="font-size:10px;">Crusader Helmet</td><td>Dwarf Mine</td></tr>
                    <tr><td>Dwarven Armor</td><td>35</td><td style="font-size:10px;">Dwarven Armor</td><td>Dwarf Mine</td></tr>
                    <tr><td>The Orc Fortress</td><td>40</td><td style="font-size:10px;">Knight Armor, Fire Sword and Knight Axe</td><td>Orc Fortress</td></tr>
                    <tr><td>The Djinn Tower</td><td>40</td><td style="font-size:10px;">Gemmed Lamp and ability to sell greater items</td><td>Orc Fortress</td></tr>
                    <tr><td>Scrapper Arena</td><td>40</td><td style="font-size:10px;">Silver Goblet and Cranial Basher or Heroic Axe or Mystic Blade</td><td>Svargrond</td></tr>
                    <tr><td>The Black Knight</td><td>50</td><td style="font-size:10px;">Crown Armor and Crown Shield</td><td>Cyclopolis</td></tr>
                    <tr><td>The Deeper Fibula</td><td>50</td><td style="font-size:10px;">Knight Axe, Warrior Helmet, Elven Amulet, Tower Shield and Dwarven Ring</td><td>The Swamp</td></tr>
                    <tr><td>The Queen of the Banshees</td><td>60</td><td style="font-size:10px;">Stealth Ring, Tower Shield, 10k, Boots of Haste, Stone Skin Amulet and Giant Sword</td><td>Graveyard</td></tr>
                    <tr><td>The Necromancer</td><td>60</td><td style="font-size:10px;">Medusa Shield, Skull Staff and Blue Robe</td><td>Yurez Lost City</td></tr>
                    <tr><td>Fire Axe</td><td>60</td><td style="font-size:10px;">Fire Axe, Ring of Healing, Dragon Necklace and 7 Small Diamonds</td><td>Dragon Lair</td></tr>
                    <tr><td>Warlord Arena</td><td>60</td><td style="font-size:10px;">Golden Goblet and Blessed Sceptre or Royal Axe or The Justice Seeker</td><td>Svargrond</td></tr>
                    <tr><td>The Warlock</td><td>70</td><td style="font-size:10px;">Vampire Shield and Dragon Lance</td><td>Graveyard</td></tr>
                    <tr><td>The Behemoth</td><td>80</td><td style="font-size:10px;">Demon Shield, Golden Armor, Guardian Halberd, Platinum Amulet, Life Ring, Crystal Ring, 3 Small Diamonds and 4 Small Sapphires</td><td>Cyclopolis</td></tr>
                    <tr><td>Pits of Inferno</td><td>80</td><td style="font-size:10px;">Backpack of Holding, Stuffed Dragon, Frozen Starlight, Soft Boots, 10k and The Avenger or Arcane Staff or Arbalest</td><td>Plains of Havoc</td></tr>
                    <tr><td>In Service of Yalahar*</td><td>80</td><td style="font-size:10px;">Yalahari Mask or Yalahari Armor or Yalahari Leg Piece</td><td>Yalahar</td></tr>
                    <tr><td>The Elemental Spheres*</td><td>80</td><td style="font-size:10px;">Dragon Robe or Greenwood Coat or Windborn Colossus Armor or The Ironworker</td><td>? ? ?</td></tr>
                    <tr><td>Wrath of the Emperor*</td><td>80</td><td style="font-size:10px;">Spiritual Charm, Black Jade Cobra, 10k, 10 Red Dragon Scales, 5 Gold Ingots, 10 Black Pearls, Blue Gem, Dragon Backpack, Jewelled Backpack and Elite Draken Helmet or Royal Draken Mail or Royal Scale Robe</td><td>? ? ?</td></tr>
                    <tr><td>Demon Helmet</td><td>100</td><td style="font-size:10px;">Demon Helmet, Demon Shield and Steel Boots</td><td>Graveyard</td></tr>
                    <tr><td>The Annihilator</td><td>100</td><td style="font-size:10px;">Demon Armor or Magic Sword or Stonecutter Axe or Present Box</td><td>Graveyard</td></tr>
                    <tr><td>The Demon Oak*</td><td>120</td><td style="font-size:10px;">Demon Legs or Rainbow Shield or Spellbook of Ancient Arcana or Thorn Spitter</td><td>Plains of Havoc</td></tr>
                    <tr><td>Ferumbras\' Ascendant Quest*</td><td>150</td><td style="font-size:10px;">5 Silver Tokens, Ferumbras\' Teddy, 4 Folded Rift Carpets, 4 Rift Tapestries, 100k and Ferumbras\' Hat or Mysterious Scroll. </td><td>? ? ?</td></tr>
                    <tr><td style="font-size:10px;">* coming soon</td></tr>
                    </table></center>
                </div>
            </div>
        </div>';

        // TASKS
        $main_content .= '
        <div id="TickerEntry-5" class="Row" onclick="TickerAction(&quot;TickerEntry-5&quot;)">
            <div class="NewsTickerIcon"></div>
            <div id="TickerEntry-5-Button" class="NewsTickerExtend" style="background-image: url('.$layout_name.'/images/general/plus.gif);"></div>
            <div class="NewsTickerText">
                <div id="TickerEntry-5-ShortText" class="NewsTickerShortText" style="display: block;"><b>Tasks</b> ...</div>
                <div id="TickerEntry-5-FullText" class="NewsTickerFullText" style="display: none;">
                    <center><table border="0" style="width:100%;text-align:center;">
                    <tr><td><b>Task</b></td><td><b>Amount</b></td><td><b>Gold</b></td><td><b>Experience</b></td><td><b>Skillpoints</b></td></tr>
                    <tr><td>Trolls</td><td>25</td><td>1k</td><td>5.000 exp</td><td>-</td></tr>
                    <tr><td>Orcs</td><td>25</td><td>1.5k</td><td>6.250 exp</td><td>-</td></tr>
                    <tr><td>Rotworms</td><td>50</td><td>2.5k</td><td>10.000 exp</td><td>-</td></tr>
                    <tr><td>Minotaurs</td><td>50</td><td>2.5k</td><td>25.000 exp</td><td>-</td></tr>
                    <tr><td>Amazons</td><td>75</td><td>3.5k</td><td>45.000 exp</td><td>-</td></tr>
                    <tr><td>Ghouls</td><td>75</td><td>4k</td><td>63.750 exp</td><td>-</td></tr>
                    <tr><td>Cyclops</td><td>100</td><td>5k</td><td>150.000 exp</td><td>-</td></tr>
                    <tr><td>Vampires</td><td>100</td><td>5k</td><td>152.500 exp</td><td>-</td></tr>
                    <tr><td>Necromancers</td><td>100</td><td>5k</td><td>290.000 exp</td><td>-</td></tr>
                    <tr><td>Dragons</td><td>100</td><td>10k</td><td>-</td><td>1</td></tr>
                    <tr><td>Bog Raiders</td><td>100</td><td>10k</td><td>-</td><td>1</td></tr>
                    <tr><td>Giant Spiders</td><td>150</td><td>10k</td><td>-</td><td>1</td></tr>
                    <tr><td>Quara Predators</td><td>150</td><td>10k</td><td>-</td><td>1</td></tr>
                    <tr><td>Heroes</td><td>150</td><td>10k</td><td>-</td><td>1</td></tr>
                    <tr><td>Massive Fire Elementals</td><td>150</td><td>10k</td><td>-</td><td>2</td></tr>
                    <tr><td>Dragon Lords</td><td>200</td><td>40k</td><td>-</td><td>2</td></tr>
                    <tr><td>Frost Dragons</td><td>200</td><td>40k</td><td>-</td><td>2</td></tr>
                    <tr><td>Hydras</td><td>250</td><td>50k</td><td>-</td><td>2</td></tr>
                    <tr><td>Behemoths</td><td>250</td><td>50k</td><td>-</td><td>2</td></tr>
                    <tr><td>Serpent Spawns</td><td>200</td><td>50k</td><td>-</td><td>3</td></tr>
                    <tr><td>Grim Reapers</td><td>200</td><td>50k</td><td>-</td><td>4</td></tr>
                    <tr><td>Demons</td><td>250</td><td>100k</td><td>-</td><td>4</td></tr>
                    <tr><td>Hellhounds</td><td>200</td><td>70k</td><td>-</td><td>4</td></tr>
                    </table></center>
                </div>
            </div>
        </div>';

        // EVENTS
        $main_content .= '
        <div id="TickerEntry-6" class="Row" onclick="TickerAction(&quot;TickerEntry-6&quot;)">
            <div class="NewsTickerIcon"></div>
            <div id="TickerEntry-6-Button" class="NewsTickerExtend" style="background-image: url('.$layout_name.'/images/general/plus.gif);"></div>
            <div class="NewsTickerText">
                <div id="TickerEntry-6-ShortText" class="NewsTickerShortText" style="display: block;"><b>Events</b> ...</div>
                <div id="TickerEntry-6-FullText" class="NewsTickerFullText" style="display: none;">
                    <center><table border="0" style="width:100%;text-align:center;">
                    <tr><td><b>Event</b></td><td><b>Day</b></td><td><b>Hour (BRT)</b></td><td><b>Reward (Win)</b></td><td><b>Reward (Tie)</b></td></tr>
                    <tr><td>Capture the Flag</td><td>Saturday (Sábado)</td><td>21h</td><td>Blue Robe + 3k</td><td>3k</td></tr>
                    <tr><td colspan=5 style="font-size:11px;"><font color=red>Red</font> and <font color=green>Green</font> team players have to take the enemy\'s flag and bring back to base. If the enemy stole your team\'s flag, you will have to kill him in order to get it back, then you can deliver their flag to your base to score the point.</td></tr>
                    </table></center>
                </div>
            </div>
        </div>';

        // RAIDS
        $main_content .= '
        <div id="TickerEntry-7" class="Row" onclick="TickerAction(&quot;TickerEntry-7&quot;)">
            <div class="NewsTickerIcon"></div>
            <div id="TickerEntry-7-Button" class="NewsTickerExtend" style="background-image: url('.$layout_name.'/images/general/plus.gif);"></div>
            <div class="NewsTickerText">
                <div id="TickerEntry-7-ShortText" class="NewsTickerShortText" style="display: block;"><b>Raids</b> ...</div>
                <div id="TickerEntry-7-FullText" class="NewsTickerFullText" style="display: none;">
                    <center><table border="0" style="width:100%;text-align:center;">
                    <tr><td><b>Raid</b></td><td width="30%"><b>Day</b></td><td><b>Hour (BRT)</b></td><td><b>Location</b></td><td><b>Boss</b></td><td><b>Items</b></td></tr>
                    <tr><td>Orcs</td><td>Monday (Segunda-Feira)</td><td>21h</td><td>Orc Fortress<br>Rhyves East Gate</td><td>Warlord Ruzad</td><td>-</td></tr>
                    <tr><td>Amazons</td><td>Tuesday (Terça-Feira)</td><td>21h</td><td>Amazon Camp<br>The Swamp</td><td>Xenia</td><td>Amazon Shield</td></tr>
                    <tr><td>Cyclops</td><td>Wednesday (Quarta-Feira)</td><td>21h</td><td>Around Cyclopolis</td><td>The Old Whopper</td><td>-</td></tr>
                    <tr><td>Undeads</td><td>Thursday (Quinta-Feira)</td><td>21h</td><td>Cemetery Quarter<br>Yalahar North Gate</td><td>Lersatio</td><td>-</td></tr>
                    <tr><td>Lizards</td><td>Friday (Sexta-Feira)</td><td>21h</td><td>Near the Pharaoh\'s Pyramid</td><td>Fazzrah</td><td>-</td></tr>
                    <tr><td>Barbarians</td><td>Saturday (Sábado)</td><td>15h</td><td>Svargrond</td><td>Leviathan</td><td>-</td></tr>
                    <tr><td>Dragons</td><td>Sunday (Domingo)</td><td>21h</td><td>Desert Outpost</td><td>Demodras</td><td>-</td></tr>
                    </table></center>
                </div>
            </div>
        </div>';

        // MAP
        $main_content .= '
        <div id="TickerEntry-8" class="Row" onclick="TickerAction(&quot;TickerEntry-8&quot;)">
            <div class="NewsTickerIcon"></div>
            <div id="TickerEntry-8-Button" class="NewsTickerExtend" style="background-image: url('.$layout_name.'/images/general/plus.gif);"></div>
            <div class="NewsTickerText">
                <div id="TickerEntry-8-ShortText" class="NewsTickerShortText" style="display: block;"><b>Map</b> ...</div>
                <div id="TickerEntry-8-FullText" class="NewsTickerFullText" style="display: none;">
                <table border="0" cellspacing="1" cellpadding="4" width="%" align="center">
                    <tr>
                        <td style="font-weight:bold">
                            <center>Fibula World</center>
                        </td>
                    </tr>
                    <tr>
                        <td>
                            <center>
                            <a href="images/fullmap.png" target="_blank">
                            <img style="width:100%;" border="1" src="images/fullmap.png">
                            </a>
                            </center>
                        <td>
                    </tr>
                </table>
                </div>
            </div>
        </div>';

        $main_content .= '
    </div>
</div>';
