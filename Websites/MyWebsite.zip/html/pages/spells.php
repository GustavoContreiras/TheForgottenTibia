<?php
 
if(!defined('INITIALIZED'))
    exit;
    $main_content .= '<table style="width:98%; border:1px solid black;text-align:center" cellspacing="1" cellpadding="4" align="center"><TR style="text-align:center;" BGCOLOR='.$config['site']['vdarkborder'].'><TD style="border:1px solid black;" colspan="7" CLASS=white><B><font CLASS=white>Spells</B></TD></TR><TR style="text-align:center;" BGCOLOR='.$config['site']['vdarkborder'].'><TD style="border:1px solid black;" CLASS=white><B><font CLASS=white>Name</B></TD><TD style="border:1px solid black;" CLASS=white><B><font CLASS=white>Words</B></TD><TD style="border:1px solid black;" CLASS=white><B><font CLASS=white>Intelligence</B></TD><TD style="border:1px solid black;" CLASS=white><B><font CLASS=white>Faith</B></TD><TD style="border:1px solid black;" CLASS=white><B><font CLASS=white>Strenght</B></TD><TD style="border:1px solid black;" CLASS=white><B><font CLASS=white>Dexterity</B></TD><TD style="border:1px solid black;" CLASS=white><B><font CLASS=white>Mana</B></TD></TR>';
$stages = new DOMDocument();
if($stages->load($config['site']['serverPath'] . 'data/spells/spells.xml'))
{
    foreach($stages->getElementsByTagName('instant') as $stage)
    {
        if($stage->getAttribute('group') == "healing" or $stage->getAttribute('group') == "support" or $stage->getAttribute('group') == "attack")
        {
            if(is_int($number_of_rows / 2)) { $bgcolor = $config['site']['lightborder']; } else { $bgcolor = $config['site']['darkborder']; } $number_of_rows++;
            $main_content .= '<TR style="text-align:center;"  BGCOLOR="'.$bgcolor.'"><TD style="border:1px solid black;">'.$stage->getAttribute('name').'</TD><TD style="border:1px solid black;"><i>'.$stage->getAttribute('words').'</i></TD><TD style="border:1px solid black;">'.$stage->getAttribute('intelligence').'</TD><TD style="border:1px solid black;">'.$stage->getAttribute('faith').'</TD><TD style="border:1px solid black;">'.$stage->getAttribute('strenght').'</TD><TD style="border:1px solid black;">'.$stage->getAttribute('dexterity').'</TD><TD style="border:1px solid black;">'.$stage->getAttribute('mana').'</TD></TR>';
        }
    }
}
$main_content .= '</table><br>';/*
$main_content .= '<TABLE BORDER=0 CELLSPACING=1 CELLPADDING=4 WIDTH=100%><TR style="text-align:center;" BGCOLOR='.$config['site']['vdarkborder'].'><TD colspan="7" CLASS=white><B><font CLASS=white>Support Spells</B></TD></TR><TR style="text-align:center;" BGCOLOR='.$config['site']['vdarkborder'].'><TD CLASS=white><B><font CLASS=white>Name</B></TD><TD CLASS=white><B><font CLASS=white>Words</B></TD><TD CLASS=white><B><font CLASS=white>Intelligence</B></TD><TD CLASS=white><B><font CLASS=white>Faith</B></TD><TD CLASS=white><B><font CLASS=white>Mana</B></TD></TR>';
/*$stages = new DOMDocument();
if($stages->load($config['site']['serverPath'] . 'data/spells/spells.xml'))
{
    foreach($stages->getElementsByTagName('instant') as $stage)
    {
        if($stage->getAttribute('group') == "support")
        {
            if(is_int($number_of_rows / 2)) { $bgcolor = $config['site']['lightborder']; } else { $bgcolor = $config['site']['darkborder']; } $number_of_rows++;
            $main_content .= '<TR style="text-align:center;"  BGCOLOR="'.$bgcolor.'"><TD>'.$stage->getAttribute('name').'</TD><TD><i>'.$stage->getAttribute('words').'</i></TD><TD>'.$stage->getAttribute('intelligence').'</TD><TD>'.$stage->getAttribute('faith').'</TD><TD>'.$stage->getAttribute('mana').'</TD></TR>';
        }
    }
}
$main_content .= '</table><br>';*/
/*$main_content .= '<TABLE BORDER=0 CELLSPACING=1 CELLPADDING=4 WIDTH=100%><TR style="text-align:center;" BGCOLOR='.$config['site']['vdarkborder'].'><TD colspan="7" CLASS=white><B><font CLASS=white>Attack Spells</B></TD></TR><TR style="text-align:center;" BGCOLOR='.$config['site']['vdarkborder'].'><TD CLASS=white><B><font CLASS=white>Name</B></TD><TD CLASS=white><B><font CLASS=white>Words</B></TD><TD CLASS=white><B><font CLASS=white>Intelligence</B></TD><TD CLASS=white><B><font CLASS=white>Faith</B></TD><TD CLASS=white><B><font CLASS=white>Mana</B></TD></TR>';
$stages = new DOMDocument();
if($stages->load($config['site']['serverPath'] . 'data/spells/spells.xml'))
{
    foreach($stages->getElementsByTagName('instant') as $stage)
    {
        if($stage->getAttribute('group') == "attack")
        {
            if(is_int($number_of_rows / 2)) { $bgcolor = $config['site']['lightborder']; } else { $bgcolor = $config['site']['darkborder']; } $number_of_rows++;
            $main_content .= '<TR style="text-align:center;"  BGCOLOR="'.$bgcolor.'"><TD>'.$stage->getAttribute('name').'</TD><TD><i>'.$stage->getAttribute('words').'</i></TD><TD>'.$stage->getAttribute('intelligence').'</TD><TD>'.$stage->getAttribute('faith').'</TD><TD>'.$stage->getAttribute('mana').'</TD></TR>';
        }
    }
}
$main_content .= '</table><br>';*/
$main_content .= '<table style="width:98%; border:1px solid black;text-align:center" cellspacing="1" cellpadding="4" align="center"><TR style="text-align:center;" BGCOLOR='.$config['site']['vdarkborder'].'><TD style="border:1px solid black;" colspan="7" CLASS=white><B><font CLASS=white>Runes</B></TD style="border:1px solid black;"></TR><TR style="text-align:center;" BGCOLOR='.$config['site']['vdarkborder'].'><TD style="border:1px solid black;" CLASS=white><B><font CLASS=white>Name</B></TD><TD style="border:1px solid black;" CLASS=white><B><font CLASS=white>Magic</B></TD><TD style="border:1px solid black;" CLASS=white><B><font CLASS=white>Intelligence</B></TD><TD style="border:1px solid black;" CLASS=white><B><font CLASS=white>Faith</B></TD><TD style="border:1px solid black;" CLASS=white><B><font CLASS=white>Type</B></TD></TR>';
$stages = new DOMDocument();
if($stages->load($config['site']['serverPath'] . 'data/spells/spells.xml'))
{
    foreach($stages->getElementsByTagName('rune') as $stage)
    {
        if($stage->hasAttribute('group'))
        {
            if(is_int($number_of_rows / 2)) { $bgcolor = $config['site']['lightborder']; } else { $bgcolor = $config['site']['darkborder']; } $number_of_rows++;
            $main_content .= '<TR style="text-align:center;"  BGCOLOR="'.$bgcolor.'"><TD style="border:1px solid black;">'.$stage->getAttribute('name').'</TD><TD style="border:1px solid black;">'.$stage->getAttribute('magiclevel').'</TD><TD style="border:1px solid black;">'.$stage->getAttribute('intelligence').'</TD><TD style="border:1px solid black;">'.$stage->getAttribute('faith').'</TD><TD style="border:1px solid black;">'.$stage->getAttribute('group').'</TD></TR>';
        }
    }
}
$main_content .= '</table>';

;?>
