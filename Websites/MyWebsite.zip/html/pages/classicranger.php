<?php
if(!defined('INITIALIZED'))
	exit;

$main_content .= '
<table>
	<tr>
		<td style="width:30%;">
			<table style="width:98%; border:1px solid black;text-align:center" cellspacing="1" cellpadding="4" align="center">
				<tr bgcolor="'.$config['site']['vdarkborder'].'">
					<td colspan="2" style="font-weight:bold;color:white;">
						Classic Ranger Build* (Level 30)
					</td>
				</tr>
				<tr bgcolor="'.$config['site']['vdarkborder'].'">
					<td style="font-weight:bold;color:white;width:50%">
						<b>The Forgotten Tibia</b>
					</td>
					<td style="font-weight:bold;color:white;width:50%">
						<b>Classic Tibia</b>
					</td>
				</tr>
				<tr bgcolor="'.$config['site']['vdarkborder'].'">
					<td colspan="3" style="font-weight:bold;color:white;width:50%">
						<b>Skills</b>
					</td>
				</tr>
				<tr bgcolor="' . $bgcolor . '">
					<td width="50%" style="border:1px solid black;">
						Magic: 0<br>
						Vitality: 8<br>
						Strenght: 8<br>
						Defence: 8<br>
						Dexterity: 8<br>
						Intelligence: 8<br>
						Faith: 8<br>
						Endurance: 8<br>
					</td>
					<td width="50%" style="border:1px solid black;">
						Magic: 7<br>
						Fist: 10<br>
						Club: 10<br>
						Sword: 10<br>
						Axe: 10<br>
						Shielding: 58<br>
						Distance: 65<br>
						Fishing: ~<br>
					</td>
				</tr>
				<tr bgcolor="'.$config['site']['vdarkborder'].'">
					<td colspan="3" style="font-weight:bold;color:white;width:50%">
						<b>Stats</b>
					</td>
				</tr>
				<tr bgcolor="' . $bgcolor . '">
					<td style="border:1px solid black;">
						Health: <font color="darkred">0</font><br>
						Mana: <font color="darkblue">0</font><br>
						Capacity: <font color="gray">0</font><br>
					</td>
					<td style="border:1px solid black;">
						Health: <font color="darkred">405</font><br>
						Mana: <font color="darkblue">420</font><br>
						Capacity: <font color="gray">910</font><br>
					</td>
				</tr>
				<tr bgcolor="'.$config['site']['vdarkborder'].'">
					<td colspan="3" style="font-weight:bold;color:white;width:50%">
						<b>Spells</b>
					</td>
				</tr>
				<tr bgcolor="' . $bgcolor . '">
					<td colspan="3" style="border:1px solid black;">
						Check out our spell list.
					</td>
				</tr>
			</table>
		</td>
		<td style="width:30%;text-align:center">
			<table style="width:98%; border:1px solid black;text-align:center" cellspacing="1" cellpadding="4" align="center">
				<tr bgcolor="'.$config['site']['vdarkborder'].'">
					<td colspan="2" style="font-weight:bold;color:white;">
						<center>Classic Ranger Build* (Level 60)</center>
					</td>
				</tr>
				<tr bgcolor="'.$config['site']['vdarkborder'].'">
					<td style="font-weight:bold;color:white;width:50%">
						<b>The Forgotten Tibia</b>
					</td>
					<td style="font-weight:bold;color:white;width:50%">
						<b>Classic Tibia</b>
					</td>
				</tr>
				<tr bgcolor="'.$config['site']['vdarkborder'].'">
					<td colspan="3" style="font-weight:bold;color:white;width:50%">
						<b>Skills</b>
					</td>
				</tr>
				<tr bgcolor="' . $bgcolor . '">
					<td width="50%" style="border:1px solid black;">
						Magic: 0<br>
						Vitality: 8<br>
						Strenght: 8<br>
						Defence: 8<br>
						Dexterity: 8<br>
						Intelligence: 8<br>
						Faith: 8<br>
						Endurance: 8<br>
					</td>
					<td width="50%" style="border:1px solid black;">
						Magic: 12<br>
						Fist: 10<br>
						Club: 10<br>
						Sword: 10<br>
						Axe: 10<br>
						Shielding: 78<br>
						Distance: 85<br>
						Fishing: ~<br>
					</td>
				</tr>
				<tr bgcolor="'.$config['site']['vdarkborder'].'">
					<td colspan="3" style="font-weight:bold;color:white;width:50%">
						<b>Stats</b>
					</td>
				</tr>
				<tr bgcolor="' . $bgcolor . '">
					<td style="border:1px solid black;">
						Health: <font color="darkred">0</font><br>
						Mana: <font color="darkblue">0</font><br>
						Capacity: <font color="gray">0</font><br>
					</td>
					<td style="border:1px solid black;">
						Health: <font color="darkred">705</font><br>
						Mana: <font color="darkblue">870</font><br>
						Capacity: <font color="gray">1510</font><br>
					</td>
				</tr>
				<tr bgcolor="'.$config['site']['vdarkborder'].'">
					<td colspan="3" style="font-weight:bold;color:white;width:50%">
						<b>Spells</b>
					</td>
				</tr>
				<tr bgcolor="' . $bgcolor . '">
					<td colspan="2" style="border:1px solid black;">
						Check out our spell list.
					</td>
				</tr>
			</table>
		</td>
	</tr>
	<tr>
		<td colspan="2">
			<table style="width:99%; border:1px solid black;text-align:left" cellspacing="1" cellpadding="4" align="center">
				<tr>
					<td style="border:1px solid black;">
						* It is not possible to make the classic paladin. The ranger build has many possible combinations:<br>
						- Increasing faith to use healing, divine and support spells/runes<br>
						- Increasing intelligence to use elementals attack spells/runes<br>
						- Increasing strenght to get more attack power with bows and crossbows<br>
						- Increasing defence to hunt with spears and shields<br>
					</td>
				</tr>
			</table>
		</td>
	</tr>
</table>';
