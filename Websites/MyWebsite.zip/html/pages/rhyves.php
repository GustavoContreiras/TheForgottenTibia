<?php
if(!defined('INITIALIZED'))
	exit;

$main_content .= '
<table border="0" cellspacing="1" cellpadding="4" width="%" align="center">
	<tr bgcolor="'.$config['site']['vdarkborder'].'">
		<td colspan="2" style="font-weight:bold;color:white">
			<center>The Forgotten Tibia</center>
		</td>
	</tr>
	<tr bgcolor="' . $bgcolor . '">
		<td>
			<center><img style="width:100%;" border="2" src="images/minimap.png"></center>
		<td>
	</tr>
</table>';
