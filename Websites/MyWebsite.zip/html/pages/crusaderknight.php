<?php
if(!defined('INITIALIZED'))
	exit;

$main_content .= '
<table>
	<tr>
		<td style="width:30%;">
			<table style="width:98%; border:1px solid black;text-align:center" cellspacing="1" cellpadding="4" align="center">
				<tr bgcolor="'.$config['site']['vdarkborder'].'">
					<td colspan="2" style="font-weight:bold;color:white;">
						Crusader Knight Build (Level 30)
					</td>
				</tr>
				<tr bgcolor="'.$config['site']['vdarkborder'].'">
					<td colspan="3" style="font-weight:bold;color:white;width:50%">
						<b>Skills</b>
					</td>
				</tr>
				<tr bgcolor="' . $bgcolor . '">
					<td colspan="2" style="border:1px solid black;">
						Magic: 5<br>
						Vitality: 8<br>
						Strenght: 62<br>
						Defence: 37<br>
						Dexterity: 8<br>
						Intelligence: 8<br>
						Faith: 22<br>
						Endurance: 8<br>
					</td>
				</tr>
				<tr bgcolor="'.$config['site']['vdarkborder'].'">
					<td colspan="3" style="font-weight:bold;color:white;width:50%">
						<b>Stats</b>
					</td>
				</tr>
				<tr bgcolor="' . $bgcolor . '">
					<td colspan="2" style="border:1px solid black;">
						Health: <font color="darkred">410</font><br>
						Mana: <font color="darkblue">370</font><br>
						Capacity: <font color="gray">925</font><br>
					</td>
				</tr>
				<tr bgcolor="'.$config['site']['vdarkborder'].'">
					<td colspan="3" style="font-weight:bold;color:white;width:50%">
						<b>Spells</b>
					</td>
				</tr>
				<tr bgcolor="' . $bgcolor . '">
					<td colspan="2" style="border:1px solid black;">
						Light<br>
						Find Person<br>
						Magic Rope<br>
						Light Healing<br>
						Cure Poison<br>
						Great Light<br>
						Levitate<br>
						Create Food<br>
						Haste<br>
						Create Cure Poison Rune<br>
						Cure Burning<br>
						Magic Shield<br>
						Cure Electrification<br>
						Create Blank Rune<br>
						Cure Bleeding<br>
						Intense Healing<br>
						Creature Illusion<br>
						Whirlwind Throw<br>					
					</td>
				</tr>
			</table>
		</td>
		<td style="width:30%;text-align:center; vertical-align:top;">
			<table style="width:98%; border:1px solid black;text-align:center;" cellspacing="1" cellpadding="4" align="center">
				<tr bgcolor="'.$config['site']['vdarkborder'].'">
					<td colspan="2" style="font-weight:bold;color:white;">
						Crusader Knight Build (Level 60)
					</td>
				</tr>
				<tr bgcolor="'.$config['site']['vdarkborder'].'">
					<td colspan="3" style="font-weight:bold;color:white;width:50%">
						<b>Skills</b>
					</td>
				</tr>
				<tr bgcolor="' . $bgcolor . '">
					<td colspan="2" style="border:1px solid black;">
						Magic: 9<br>
						Vitality: 20<br>
						Strenght: 85<br>
						Defence: 60<br>
						Dexterity: 8<br>
						Intelligence: 8<br>
						Faith: 30<br>
						Endurance: 30<br>
					</td>
				</tr>
				<tr bgcolor="'.$config['site']['vdarkborder'].'">
					<td colspan="3" style="font-weight:bold;color:white;width:50%">
						<b>Stats</b>
					</td>
				</tr>
				<tr bgcolor="' . $bgcolor . '">
					<td colspan="2" style="border:1px solid black;">
						Health: <font color="darkred">965</font><br>
						Mana: <font color="darkblue">660</font><br>
						Capacity: <font color="gray">1670</font><br>
					</td>
				</tr>
				<tr bgcolor="'.$config['site']['vdarkborder'].'">
					<td colspan="3" style="font-weight:bold;color:white;width:50%">
						<b>Spells</b>
					</td>
				</tr>
				<tr bgcolor="' . $bgcolor . '">
					<td colspan="2" style="border:1px solid black;">
						(...)<br>
						Strong Haste<br>
						Ultimate Light<br>
						Create Chameleon Rune<br>
						Ultimate Healing<br>
						Groundshaker<br>	
					</td>
				</tr>
			</table>
		</td>
	</tr>
</table>';
