<?php
if(!defined('INITIALIZED'))
	exit;

$main_content .= '
<table>
	<tr>
		<td style="width:30%;">
			<table style="width:98%; border:1px solid black;text-align:center" cellspacing="1" cellpadding="4" align="center">
				<tr bgcolor="'.$config['site']['vdarkborder'].'">
					<td colspan="2" style="font-weight:bold;color:white;">
						Classic Knight Build (Level 30)
					</td>
				</tr>
				<tr bgcolor="'.$config['site']['vdarkborder'].'">
					<td style="font-weight:bold;color:white;width:50%">
						<b>The Forgotten Tibia</b>
					</td>
					<td style="font-weight:bold;color:white;width:50%">
						<b>Classic Tibia</b>
					</td>
				</tr>
				<tr bgcolor="'.$config['site']['vdarkborder'].'">
					<td colspan="3" style="font-weight:bold;color:white;width:50%">
						<b>Skills</b>
					</td>
				</tr>
				<tr bgcolor="' . $bgcolor . '">
					<td width="50%" style="border:1px solid black;">
						Magic: 0<br>
						Vitality: 8<br>
						Strenght: 61<br>
						Defence: 58<br>
						Dexterity: 8<br>
						Intelligence: 8<br>
						Faith: 14<br>
						Endurance: 8<br>
					</td>
					<td width="50%" style="border:1px solid black;">
						Magic: 3<br>
						Fist: 10<br>
						Club: 10<br>
						Sword: 10<br>
						Axe: 61<br>
						Shielding: 58<br>
						Distance: 10<br>
						Fishing: ~<br>
					</td>
				</tr>
				<tr bgcolor="'.$config['site']['vdarkborder'].'">
					<td colspan="3" style="font-weight:bold;color:white;width:50%">
						<b>Stats</b>
					</td>
				</tr>
				<tr bgcolor="' . $bgcolor . '">
					<td style="border:1px solid black;">
						Health: <font color="darkred">515</font><br>
						Mana: <font color="darkblue">230</font><br>
						Capacity: <font color="gray">920</font><br>
					</td>
					<td style="border:1px solid black;">
						Health: <font color="darkred">515</font><br>
						Mana: <font color="darkblue">200</font><br>
						Capacity: <font color="gray">1020</font><br>
					</td>
				</tr>
				<tr bgcolor="'.$config['site']['vdarkborder'].'">
					<td colspan="3" style="font-weight:bold;color:white;width:50%">
						<b>Spells</b>
					</td>
				</tr>
				<tr bgcolor="' . $bgcolor . '">
					<td colspan="3" style="border:1px solid black;">
						Check out our spell list.
					</td>
				</tr>
			</table>
		</td>
		<td style="width:30%;text-align:center;">
			<table style="width:98%; border:1px solid black;text-align:center" cellspacing="1" cellpadding="4" align="center">
				<tr bgcolor="'.$config['site']['vdarkborder'].'">
					<td colspan="2" style="font-weight:bold;color:white;">
						<center>Classic Knight Build (Level 60)</center>
					</td>
				</tr>
				<tr bgcolor="'.$config['site']['vdarkborder'].'">
					<td style="font-weight:bold;color:white;width:50%">
						<b>The Forgotten Tibia</b>
					</td>
					<td style="font-weight:bold;color:white;width:50%">
						<b>Classic Tibia</b>
					</td>
				</tr>
				<tr bgcolor="'.$config['site']['vdarkborder'].'">
					<td colspan="3" style="font-weight:bold;color:white;width:50%">
						<b>Skills</b>
					</td>
				</tr>
				<tr bgcolor="' . $bgcolor . '">
					<td width="50%" style="border:1px solid black;">
						Magic: 4<br>
						Vitality: 21<br>
						Strenght: 80<br>
						Defence: 80<br>
						Dexterity: 8<br>
						Intelligence: 8<br>
						Faith: 19<br>
						Endurance: 40<br>
					</td>
					<td width="50%" style="border:1px solid black;">
						Magic: 4<br>
						Fist: 10<br>
						Club: 10<br>
						Sword: 10<br>
						Axe: 80<br>
						Shielding: 78<br>
						Distance: 10<br>
						Fishing: ~<br>
					</td>
				</tr>
				<tr bgcolor="'.$config['site']['vdarkborder'].'">
					<td colspan="3" style="font-weight:bold;color:white;width:50%">
						<b>Stats</b>
					</td>
				</tr>
				<tr bgcolor="' . $bgcolor . '">
					<td style="border:1px solid black;">
						Health: <font color="darkred">1130</font><br>
						Mana: <font color="darkblue">475</font><br>
						Capacity: <font color="gray">1795</font><br>
					</td>
					<td style="border:1px solid black;">
						Health: <font color="darkred">965</font><br>
						Mana: <font color="darkblue">350</font><br>
						Capacity: <font color="gray">1770</font><br>
					</td>
				</tr>
				<tr bgcolor="'.$config['site']['vdarkborder'].'">
					<td colspan="3" style="font-weight:bold;color:white;width:50%">
						<b>Spells</b>
					</td>
				</tr>
				<tr bgcolor="' . $bgcolor . '">
					<td colspan="2" style="border:1px solid black;">
						Check out our spell list.
					</td>
				</tr>
			</table>
		</td>
	</tr>
</table>';
