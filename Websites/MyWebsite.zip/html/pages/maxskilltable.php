<?php
if(!defined('INITIALIZED'))
	exit;

$main_content .= '
<table style="width:98%; border:1px solid black;text-align:center" cellspacing="1" cellpadding="4" align="center">
	<tr bgcolor="'.$config['site']['vdarkborder'].'">
		<td style="font-weight:bold;color:white;">
			Level
		</td>
		<td style="font-weight:bold;color:white;">
			Magic
		</td>
		<td style="font-weight:bold;color:white;">
			Vitality
		</td>
		<td style="font-weight:bold;color:white;">
			Strenght
		</td>
		<td style="font-weight:bold;color:white;">
			Defence
		</td>
		<td style="font-weight:bold;color:white;">
			Dexterity
		</td>
		<td style="font-weight:bold;color:white;">
			Faith
		</td>
		<td style="font-weight:bold;color:white;">
			Intelligence
		</td>
		<td style="font-weight:bold;color:white;">
			Endurance
		</td>
	</tr>';
	for($level = 8; $level <= 155; $level++) {

		$bgcolor = (($number_of_rows++ % 2 == 1) ?  $config['site']['darkborder'] : $config['site']['lightborder']);

		if ($level >= 8) {
			$magic 			= ceil( max( $level * max( 2.5 - (0.02 * ($level - 8)), 1 ) * 0.5, $level ) );
			$vitality 		= ceil( max( $level * max( 2.5 - (0.02 * ($level - 8)), 1 ), $level ) );
			$strenght 		= ceil( max( $level * max( 2.5 - (0.02 * ($level - 8)), 1 ), $level ) );
			$defence 		= ceil( max( $level * max( 2.5 - (0.02 * ($level - 8)), 1 ), $level ) );
			$dexterity 		= ceil( max( $level * max( 2.5 - (0.02 * ($level - 8)), 1 ), $level ) );
			$faith 			= ceil( max( $level * max( 2.5 - (0.02 * ($level - 8)), 1 ), $level ) );
			$intelligence 	= ceil( max( $level * max( 2.5 - (0.02 * ($level - 8)), 1 ), $level ) );
			$endurance 		= ceil( max( $level * max( 2.5 - (0.02 * ($level - 8)), 1 ), $level ) );
		}
		
		if ($level >= 72) {
			if ($level <= 90) {
				$bgcolor = $config['site']['lightborder'];
			}
			$magic = 72;
			$vitality = 90;
			$strenght = 90;
			$defence = 90;
			$dexterity = 90;
			$faith = 90;
			$intelligence = 90;
			$endurance = 90;
		}

		if ($level > 90) {
			$magic = ceil( 72 + $level - 90 );
			$vitality = $level;
			$strenght = $level;
			$defence = $level;
			$dexterity = $level;
			$faith = $level;
			$intelligence = $level;
			$endurance = $level;
		}

		if ($level > 100) {
			$magic = ceil( 82 + ( $level - 100 ) / 2 ) ;
			$vitality = $level;
			$strenght = $level;
			$defence = $level;
			$dexterity = $level;
			$faith = $level;
			$intelligence = $level;
			$endurance = $level;
		}

		if ($level > 130) {
			$vitality = 130;
			$strenght = 130;
			$defence = 130;
			$dexterity = 130;
			$faith = 130;
			$intelligence = 130;
			$endurance = 130;
		}

		if ($level > 135) {
			$magic = ceil( 100 + ( $level - 135 ) / 2 ) ;
			$vitality = 130;
			$strenght = 130;
			$defence = 130;
			$dexterity = 130;
			$faith = 130;
			$intelligence = 130;
			$endurance = 130;
		}

		if ($level > 153) {
			$bgcolor = $config['site']['lightborder'];
			$magic = 110;
			$vitality = 130;
			$strenght = 130;
			$defence = 130;
			$dexterity = 130;
			$faith = 130;
			$intelligence = 130;
			$endurance = 130;
		}

	if ($level == 73) {

	$main_content .= '
	<tr bgcolor="' . $bgcolor . '">
		<td width="%" style="border:1px solid black;">
			<b>...</b>
		</td>
		<td width="%" style="border:1px solid black;">
			...
		</td>
		<td width="%" style="border:1px solid black;">
			...
		</td>
		<td width="%" style="border:1px solid black;">
			...
		</td>
		<td width="%" style="border:1px solid black;">
			...
		</td>
		<td width="%" style="border:1px solid black;">
			...
		</td>
		<td width="%" style="border:1px solid black;">
			...
		</td>
		<td width="%" style="border:1px solid black;">
			...
		</td>
		<td width="%" style="border:1px solid black;">
			...
		</td>
	</tr>';

	}
	
	if ($level < 73 || $level > 89) {

	$main_content .= '
	<tr bgcolor="' . $bgcolor . '">
		<td width="%" style="border:1px solid black;">
			<b>'.$level.'</b>
		</td>
		<td width="%" style="border:1px solid black;">
			'.$magic.'
		</td>
		<td width="%" style="border:1px solid black;">
			'.$vitality.'
		</td>
		<td width="%" style="border:1px solid black;">
			'.$strenght.'
		</td>
		<td width="%" style="border:1px solid black;">
			'.$defence.'
		</td>
		<td width="%" style="border:1px solid black;">
			'.$dexterity.'
		</td>
		<td width="%" style="border:1px solid black;">
			'.$faith.'
		</td>
		<td width="%" style="border:1px solid black;">
			'.$intelligence.'
		</td>
		<td width="%" style="border:1px solid black;">
			'.$endurance.'
		</td>
	</tr>';
}
	}
	$main_content .= '
	<tr bgcolor="' . $bgcolor . '">
		<td width="%" style="border:1px solid black;">
			<b>...</b>
		</td>
		<td width="%" style="border:1px solid black;">
			...
		</td>
		<td width="%" style="border:1px solid black;">
			...
		</td>
		<td width="%" style="border:1px solid black;">
			...
		</td>
		<td width="%" style="border:1px solid black;">
			...
		</td>
		<td width="%" style="border:1px solid black;">
			...
		</td>
		<td width="%" style="border:1px solid black;">
			...
		</td>
		<td width="%" style="border:1px solid black;">
			...
		</td>
		<td width="%" style="border:1px solid black;">
			...
		</td>
	</tr>
</table>';
