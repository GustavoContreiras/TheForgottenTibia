<?php
if(!defined('INITIALIZED'))
	exit;

$main_content .= '<table style="width:98%; border:1px solid black;text-align:center" cellspacing="1" cellpadding="4" align="center"><tr bgcolor="' . $config['site']['vdarkborder'] . '"><td colspan="2" style="border:1px solid black;color:white;font-weight:bold">Server Informations</td></tr>';
$bgcolor = (($number_of_rows++ % 2 == 1) ?  $config['site']['darkborder'] : $config['site']['lightborder']);
$main_content .= '<tr bgcolor="' . $bgcolor . '"><td style="border:1px solid black;font-weight:bold;">Exp rate</td><td style="border:1px solid black;">';
$stages = new DOMDocument();
if($stages->load($config['site']['serverPath'] . 'data/XML/stages.xml') && $stages->getElementsByTagName('config')->item(0)->getAttribute('enabled'))
{
	foreach($stages->getElementsByTagName('stage') as $stage)
	{
		$main_content .= 'Level ' . $stage->getAttribute('minlevel');
		if($stage->hasAttribute('maxlevel'))
		{
			$main_content .= ' - ' . $stage->getAttribute('maxlevel') . '';
		}
		else
		{
			$main_content .= '+';
		}
		$main_content .= ', ' . $stage->getAttribute('multiplier') . 'x<br />';
	}
}
else
{
	$main_content .= $config['server']['rateExp'] . 'x';
}
$main_content .= '</td></tr>';
$bgcolor = (($number_of_rows++ % 2 == 1) ?  $config['site']['darkborder'] : $config['site']['lightborder']);
$main_content .= '<tr bgcolor="' . $bgcolor . '"><td style="border:1px solid black;font-weight:bold;">Loot rate</td><td style="border:1px solid black;">' . $config['server']['rateLoot'] . 'x</td></tr></table>';