<?php
if(!defined('INITIALIZED'))
    exit;

$main_content .= '
<center>
    <table border="0" style="width:100%;text-align:center;">
        <tr>
        <td width="10%"><b>Num.</b></td>
        <td width="30%"><b>Quest</b></td>
        <td><b>Level</b></td>
        <td><b>Reward</b></td>
        <td width="18%"><b>Location</b></td></tr>
        <tr><td>1</td><td>Greenhorn Arena*</td><td>20</td><td style="font-size:10px;">Bronze Goblet and Orcish Maul or Headchopper or Blacksteel Sword</td><td>Svargrond</td></tr>
        <tr><td>2</td><td>Crown Helmet & Noble Armor*</td><td>30</td><td style="font-size:10px;">Crown Helmet and Noble Armor</td><td> ? ? ? </td></tr>
        <tr><td>3</td><td>Crusader Helmet</td><td>35</td><td style="font-size:10px;">Crusader Helmet</td><td>Dwarf Mine</td></tr>
        <tr><td>4</td><td>Dwarven Armor</td><td>35</td><td style="font-size:10px;">Dwarven Armor</td><td>Dwarf Mine</td></tr>
        <tr><td>5</td><td>The Orc Fortress</td><td>40</td><td style="font-size:10px;">Knight Armor, Fire Sword and Knight Axe</td><td>Orc Fortress</td></tr>
        <tr><td>6</td><td>The Djinn Tower</td><td>40</td><td style="font-size:10px;">Gemmed Lamp and ability to sell greater items</td><td>Orc Fortress</td></tr>
        <tr><td>7</td><td>Scrapper Arena*</td><td>40</td><td style="font-size:10px;">Silver Goblet and Cranial Basher or Heroic Axe or Mystic Blade</td><td>Svargrond</td></tr>
        <tr><td>8</td><td>The Black Knight</td><td>50</td><td style="font-size:10px;">Crown Armor and Crown Shield</td><td>Cyclopolis</td></tr>
        <tr><td>9</td><td>The Deeper Fibula</td><td>50</td><td style="font-size:10px;">Knight Axe, Warrior Helmet, Elven Amulet, Tower Shield and Dwarven Ring</td><td>The Swamp</td></tr>
        <tr><td>10</td><td>The Queen of the Banshees</td><td>60</td><td style="font-size:10px;">Stealth Ring, Tower Shield, 10k, Boots of Haste, Stone Skin Amulet and Giant Sword</td><td>Cemetery</td></tr>
        <tr><td>11</td><td>The Necromancer</td><td>60</td><td style="font-size:10px;">Medusa Shield, Skull Staff and Blue Robe</td><td>Yurez Lost City</td></tr>
        <tr><td>12</td><td>Fire Axe</td><td>60</td><td style="font-size:10px;">Fire Axe, Ring of Healing, Dragon Necklace and 7 Small Diamonds</td><td>Dragon Lair</td></tr>
        <tr><td>13</td><td>Warlord Arena*</td><td>60</td><td style="font-size:10px;">Golden Goblet and Blessed Sceptre or Royal Axe or The Justice Seeker</td><td>Svargrond</td></tr>
        <tr><td>14</td><td>The Warlock</td><td>70</td><td style="font-size:10px;">Vampire Shield and Dragon Lance</td><td>Cemetery</td></tr>
        <tr><td>15</td><td>The Behemoth</td><td>80</td><td style="font-size:10px;">Demon Shield, Golden Armor, Guardian Halberd, Platinum Amulet, Life Ring, Crystal Ring, 3 Small Diamonds and 4 Small Sapphires</td><td>Cyclopolis</td></tr>
        <tr><td>16</td><td>Pits of Inferno</td><td>80</td><td style="font-size:10px;">Backpack of Holding, Stuffed Dragon, Frozen Starlight, Soft Boots, 10k and The Avenger or Arcane Staff or Arbalest</td><td>Cemetery</td></tr>
        <tr><td>17</td><td>In Service of Yalahar*</td><td>80</td><td style="font-size:10px;">Yalahari Mask or Yalahari Armor or Yalahari Leg Piece</td><td>Yalahar</td></tr>
        <tr><td>18</td><td>The Elemental Spheres*</td><td>80</td><td style="font-size:10px;">Dragon Robe or Greenwood Coat or Windborn Colossus Armor or The Ironworker</td><td>? ? ?</td></tr>
        <tr><td>19</td><td>Wrath of the Emperor*</td><td>80</td><td style="font-size:10px;">Spiritual Charm, Black Jade Cobra, 10k, 10 Red Dragon Scales, 5 Gold Ingots, 10 Black Pearls, Blue Gem, Dragon Backpack, Jewelled Backpack and Elite Draken Helmet or Royal Draken Mail or Royal Scale Robe</td><td>? ? ?</td></tr>
        <tr><td>20</td><td>Demon Helmet</td><td>100</td><td style="font-size:10px;">Demon Helmet, Demon Shield and Steel Boots</td><td>Cemetery</td></tr>
        <tr><td>21</td><td>The Annihilator</td><td>100</td><td style="font-size:10px;">Demon Armor or Magic Sword or Stonecutter Axe or Present Box</td><td>Cemetery</td></tr>
        <tr><td>22</td><td>The Demon Oak*</td><td>120</td><td style="font-size:10px;">Demon Legs or Rainbow Shield or Spellbook of Ancient Arcana or Thorn Spitter</td><td>Plains of Havoc</td></tr>
        <tr><td>23</td><td>Ferumbras\' Ascendant Quest*</td><td>150</td><td style="font-size:10px;">5 Silver Tokens, Ferumbras\' Teddy, 4 Folded Rift Carpets, 4 Rift Tapestries, 100k and Ferumbras\' Hat or Mysterious Scroll. </td><td>? ? ?</td></tr>
        <tr><td></td><td style="font-size:10px;">* coming soon</td></tr>
    </table>
</center>';
