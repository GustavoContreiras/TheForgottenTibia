<?php
if(!defined('INITIALIZED'))
	exit;

$main_content .= '
<table>
	<tr>
		<td style="width:30%;">
			<table style="width:98%; border:1px solid black;text-align:center" cellspacing="1" cellpadding="4" align="center">
				<tr bgcolor="'.$config['site']['vdarkborder'].'">
					<td colspan="2" style="font-weight:bold;color:white;">
						Capture the Flag
					</td>
				</tr>
				<tr bgcolor="'.$config['site']['vdarkborder'].'">
					<td colspan="2" style="font-weight:bold;color:white;width:50%">
						<b>Rewards</b>
					</td>
				</tr>
				<tr bgcolor="'.$config['site']['vdarkborder'].'">
					<td style="font-weight:bold;color:white;width:50%">
						<b>Win</b>
					</td>
					<td style="font-weight:bold;color:white;width:50%">
						<b>Tie</b>
					</td>
				</tr>
				<tr bgcolor="' . $bgcolor . '">
					<td style="border:1px solid black;">
						Blue Robe + 3k
					</td>
					<td style="border:1px solid black;">
						3k
					</td>
				</tr>
				<tr bgcolor="'.$config['site']['vdarkborder'].'">
					<td colspan="2" style="font-weight:bold;color:white;width:50%">
						<b>How it works</b>
					</td>
				</tr>
				<tr bgcolor="' . $bgcolor . '">
					<td colspan="2" style="border:1px solid black;">
						Red and Green team players have to take the enemy\'s flag and bring back to base.<br>
						If the enemy stole your team\'s flag, you will have to kill him in order to get it back.<br>
						Then you can deliver their flag to your base and score the point.
					</td>
				</tr>
				<tr bgcolor="'.$config['site']['vdarkborder'].'">
					<td colspan="3" style="font-weight:bold;color:white;width:50%">
						<b>Map</b>
					</td>
				</tr>
				<tr bgcolor="' . $bgcolor . '">
					<td colspan="2" style="border:1px solid black;">
						<center><img style="width:98%;" border="2" src="images/capturetheflag.png"></center>
					</td>
				</tr>
			</table>
		</td>
	</tr>
</table>';
