<?php
if(!defined('INITIALIZED'))
	exit;

$main_content .= '
<table style="width:98%; border:1px solid black;text-align:center" cellspacing="1" cellpadding="4" align="center">
	<tr bgcolor="'.$config['site']['vdarkborder'].'">
		<td colspan="2" style="font-weight:bold;color:white;">
			Downloads
		</td>
	</tr>
	<tr>
		<td style="border:1px solid black;">
			<a href="http://www.mediafire.com/file/vqxbr4ngyc8i62i/TheForgottenTibia_17-10-19.zip/file" target="_blank">
			The Forgotten Tibia\'s Client (53.12 MB)
			</a>
		</td>
		<td style="border:1px solid black;">
			The only way you can play in this server is through this client.
		</td>
	</tr>
	<tr>
		<td style="border:1px solid black;">
			<a href="https://download.microsoft.com/download/0/6/4/064F84EA-D1DB-4EAA-9A5C-CC2F0FF6A638/vc_redist.x86.exe">
			vc_redist.x86.exe (13.5 MB)<br>
			</a>
		</td>
		<td style="border:1px solid black;">
			A Microsoft software needed for video graphics.
		</td>
	</tr>
</table>';
