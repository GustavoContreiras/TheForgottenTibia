# touch_hotkeys
Use hotkeys in OTClient from screen using mouse or touch screen

# How to add?
* Add folder [touch_hotkeys] to "modules" or "mods" folder in your main OTClient folder.

# How to use?
* Switch on in right game toggle button. ![Icon](https://raw.githubusercontent.com/EgzoT/touch_hotkeys/master/img_touch_hotkeys/Hotkey_icon.png?token=AHCDGJJJ7NJAVZLJJ67YOZS5SJGEW)
* Window will appear (depending on previous choice, first time appear a vertical window) vertical or horizontal window.

![Vertical window](https://dl.getdropbox.com/s/4cik5gcxb09uyif/touch_hotkeys_1.png) ![Horizontal window](https://dl.getdropbox.com/s/zfeuyqcm2zv2ot2/touch_hotkeys_2.png)

* Press one of button to use hotkey who was assigned to this button. All buttons is configure in hotkeys module.

![Use hotkey](https://dl.getdropbox.com/s/2bzvtvboqel9z12/touch_hotkeys_4.png)

* To change windows type, you need to click dot icon in the top right corner.

![Change type](https://dl.getdropbox.com/s/9yq57a05iqniztq/touch_hotkeys_3.png)
